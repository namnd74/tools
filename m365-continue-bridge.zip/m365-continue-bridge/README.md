# M365 Continue Bridge

Experimental local bridge that lets the Continue VS Code extension use Microsoft 365 Copilot Web as the reasoning backend.

Architecture:

Continue Agent Mode -> OpenAI-compatible localhost bridge -> Playwright persistent browser -> Microsoft 365 Copilot Web

## Important

This is browser automation, not an official Microsoft API integration. Microsoft can change Copilot Web's DOM or behavior at any time. Use it only where your organization's policies allow browser automation and sending repository context to Microsoft 365 Copilot.

The bridge does not copy or persist access tokens/cookies itself. Authentication remains inside a dedicated persistent browser profile.

## Requirements

- Node.js 20+
- Microsoft Edge, or Playwright Chromium
- Continue extension in VS Code
- Access to Microsoft 365 Copilot Web

## Setup

```bash
npm install
cp .env.example .env
npm start
```

The first request, or POST `/login`, opens the browser profile. Complete Microsoft login/MFA there.

### Windows PowerShell

```powershell
Copy-Item .env.example .env
npm install
npm start
```

Then check:

```powershell
curl.exe http://127.0.0.1:8765/health
curl.exe http://127.0.0.1:8765/status
```

## Continue

Use the contents of `continue-config.example.yaml` as a local Continue config/agent configuration.

Select `M365 Copilot Web`, switch Continue to Agent mode, and try:

> Read package.json and tell me what framework this project uses.

Then a write task:

> Find the login handler, add a short comment above it, show me the diff, and do not change anything else.

## How tool calls work

Continue sends its tool schemas to `/v1/chat/completions`. The bridge serializes those schemas into the prompt sent to M365 Copilot Web. M365 is instructed to emit:

```xml
<continue_tool_call>
{"name":"read_file","arguments":{"filepath":"src/auth.ts"}}
</continue_tool_call>
```

The bridge converts that into an OpenAI `tool_calls` response. Continue then executes the tool in VS Code and sends the tool result on the next request.

## If Agent Mode is unavailable

The sample config adds:

```yaml
capabilities:
  - tool_use
```

Continue currently supports Agent Mode through tools and may use system-message tools for models/providers that do not have native tool calling. This bridge implements OpenAI-style tool calls itself so Continue can treat the backend as tool-capable.

## DOM selectors

All Copilot Web selectors are isolated in `src/copilot.js`. If Microsoft changes the UI, update only that file first.

The most likely selectors to need adjustment are:

- `composerCandidates`
- `sendButtonCandidates`
- `stopButtonCandidates`
- `assistantMessageCandidates`

## Session persistence

The Playwright browser profile lives at:

```text
data/browser-profile/
```

Do not commit or share that directory.

The browser profile, not `state.json`, keeps the Microsoft login session.
