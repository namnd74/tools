import crypto from "node:crypto";

const TOOL_PROTOCOL = `
You are the reasoning model behind a coding agent running inside the Continue VS Code extension.
You DO NOT have direct filesystem or terminal access. Continue owns and executes tools.

When a tool is required, output ONLY this XML block and nothing else:
<continue_tool_call>
{"name":"TOOL_NAME","arguments":{}}
</continue_tool_call>

Rules:
- Use only a tool listed in AVAILABLE_TOOLS.
- The JSON inside the XML must be valid JSON.
- Never invent a file's contents. Read/search first when necessary.
- Prefer minimal edits.
- After an edit, use diagnostics/tests when appropriate.
- If no tool is needed, answer normally.
`;

function stringifyContent(content) {
  if (typeof content === "string") return content;
  if (!Array.isArray(content)) return content == null ? "" : JSON.stringify(content);

  return content
    .map((item) => {
      if (typeof item === "string") return item;
      if (item?.type === "text") return item.text || "";
      if (item?.type === "input_text") return item.text || "";
      return `[Unsupported content item omitted: ${item?.type || "unknown"}]`;
    })
    .filter(Boolean)
    .join("\n");
}

function toolDescription(tool) {
  const fn = tool?.function || tool;
  if (!fn?.name) return null;
  return {
    name: fn.name,
    description: fn.description || "",
    parameters: fn.parameters || { type: "object", properties: {} }
  };
}

export function buildCopilotPrompt(body) {
  const messages = Array.isArray(body.messages) ? body.messages : [];
  const tools = Array.isArray(body.tools) ? body.tools.map(toolDescription).filter(Boolean) : [];

  const transcript = messages
    .map((m) => {
      const role = String(m.role || "user").toUpperCase();

      if (m.role === "tool") {
        return `TOOL_RESULT${m.name ? ` (${m.name})` : ""}:\n${stringifyContent(m.content)}`;
      }

      if (Array.isArray(m.tool_calls) && m.tool_calls.length > 0) {
        const calls = m.tool_calls
          .map((call) => `${call.function?.name || "tool"}(${call.function?.arguments || "{}"})`)
          .join("\n");
        return `${role}:\n${stringifyContent(m.content)}\nPREVIOUS_TOOL_CALLS:\n${calls}`;
      }

      return `${role}:\n${stringifyContent(m.content)}`;
    })
    .join("\n\n");

  const toolBlock = tools.length
    ? `\nAVAILABLE_TOOLS:\n${JSON.stringify(tools, null, 2)}\n`
    : "\nAVAILABLE_TOOLS: []\n";

  return `${TOOL_PROTOCOL}${toolBlock}\nCONVERSATION:\n${transcript}\n\nRespond to the latest message.`;
}

function extractJsonObject(text) {
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start === -1 || end === -1 || end <= start) return null;
  return text.slice(start, end + 1);
}

export function parseCopilotResponse(text, requestTools = []) {
  const raw = String(text || "").trim();
  const match = raw.match(/<continue_tool_call>([\s\S]*?)<\/continue_tool_call>/i);

  if (!match) {
    return {
      type: "text",
      content: raw
    };
  }

  const jsonText = extractJsonObject(match[1]);
  if (!jsonText) {
    return { type: "text", content: raw };
  }

  let parsed;
  try {
    parsed = JSON.parse(jsonText);
  } catch {
    return { type: "text", content: raw };
  }

  const name = parsed?.name;
  const args = parsed?.arguments ?? {};
  const allowed = new Set(
    (requestTools || [])
      .map((t) => t?.function?.name || t?.name)
      .filter(Boolean)
  );

  if (!name || (allowed.size > 0 && !allowed.has(name))) {
    return {
      type: "text",
      content: `Model requested an unavailable tool: ${name || "unknown"}.\n\n${raw}`
    };
  }

  return {
    type: "tool_call",
    id: `call_${crypto.randomUUID().replaceAll("-", "")}`,
    name,
    arguments: typeof args === "string" ? args : JSON.stringify(args)
  };
}

export function openAIResponse({ model, parsed }) {
  const id = `chatcmpl_${crypto.randomUUID().replaceAll("-", "")}`;
  const created = Math.floor(Date.now() / 1000);

  if (parsed.type === "tool_call") {
    return {
      id,
      object: "chat.completion",
      created,
      model,
      choices: [
        {
          index: 0,
          message: {
            role: "assistant",
            content: null,
            tool_calls: [
              {
                id: parsed.id,
                type: "function",
                function: {
                  name: parsed.name,
                  arguments: parsed.arguments
                }
              }
            ]
          },
          finish_reason: "tool_calls"
        }
      ],
      usage: {
        prompt_tokens: 0,
        completion_tokens: 0,
        total_tokens: 0
      }
    };
  }

  return {
    id,
    object: "chat.completion",
    created,
    model,
    choices: [
      {
        index: 0,
        message: {
          role: "assistant",
          content: parsed.content
        },
        finish_reason: "stop"
      }
    ],
    usage: {
      prompt_tokens: 0,
      completion_tokens: 0,
      total_tokens: 0
    }
  };
}

export function asSingleChunkSse(response) {
  const choice = response.choices?.[0];
  const delta = { role: "assistant" };

  if (choice?.message?.content != null) {
    delta.content = choice.message.content;
  }
  if (choice?.message?.tool_calls) {
    delta.tool_calls = choice.message.tool_calls.map((call, index) => ({
      index,
      ...call
    }));
  }

  const chunk = {
    id: response.id,
    object: "chat.completion.chunk",
    created: response.created,
    model: response.model,
    choices: [
      {
        index: 0,
        delta,
        finish_reason: choice?.finish_reason || "stop"
      }
    ]
  };

  return `data: ${JSON.stringify(chunk)}\n\ndata: [DONE]\n\n`;
}
