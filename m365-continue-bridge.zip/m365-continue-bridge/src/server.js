import "dotenv/config";
import Fastify from "fastify";
import { browserQueue } from "./queue.js";
import { getAuthState, getProfileDir, ensureAuthenticated, resetSession } from "./session.js";
import { sendCopilotPrompt } from "./copilot.js";
import { buildCopilotPrompt, parseCopilotResponse, openAIResponse, asSingleChunkSse } from "./parser.js";

const app = Fastify({ logger: true, bodyLimit: 20 * 1024 * 1024 });
const HOST = process.env.HOST || "127.0.0.1";
const PORT = Number(process.env.PORT || 8765);
const LOCAL_API_KEY = process.env.LOCAL_API_KEY || "";

function requireLocalKey(request, reply, done) {
  if (!LOCAL_API_KEY) return done();

  const auth = request.headers.authorization || "";
  if (auth !== `Bearer ${LOCAL_API_KEY}`) {
    reply.code(401).send({
      error: {
        message: "Invalid local bridge API key",
        type: "authentication_error"
      }
    });
    return;
  }
  done();
}

app.get("/health", async () => ({
  ok: true,
  queuePending: browserQueue.pending,
  profileDir: getProfileDir()
}));

app.get("/status", async () => {
  try {
    return {
      ok: true,
      auth: await getAuthState(),
      queuePending: browserQueue.pending
    };
  } catch (error) {
    return {
      ok: false,
      auth: "unknown",
      error: error.message,
      queuePending: browserQueue.pending
    };
  }
});

app.post("/login", async () => {
  await ensureAuthenticated({ interactive: true });
  return { ok: true, auth: "authenticated" };
});

app.post("/reset-session", async () => {
  await resetSession();
  return { ok: true };
});

app.get("/v1/models", { preHandler: requireLocalKey }, async () => ({
  object: "list",
  data: [
    {
      id: "m365-copilot-web",
      object: "model",
      owned_by: "local"
    }
  ]
}));

app.post("/v1/chat/completions", { preHandler: requireLocalKey }, async (request, reply) => {
  const body = request.body || {};
  const model = body.model || "m365-copilot-web";

  try {
    const response = await browserQueue.run(async () => {
      const prompt = buildCopilotPrompt(body);
      const text = await sendCopilotPrompt(prompt);
      const parsed = parseCopilotResponse(text, body.tools || []);
      return openAIResponse({ model, parsed });
    });

    if (body.stream === true) {
      reply
        .header("Content-Type", "text/event-stream")
        .header("Cache-Control", "no-cache")
        .header("Connection", "keep-alive");
      return reply.send(asSingleChunkSse(response));
    }

    return response;
  } catch (error) {
    request.log.error(error);
    return reply.code(502).send({
      error: {
        message: error.message,
        type: "m365_copilot_bridge_error"
      }
    });
  }
});

app.listen({ host: HOST, port: PORT })
  .then(() => {
    app.log.info(`M365 Continue Bridge listening on http://${HOST}:${PORT}`);
    app.log.info(`Health: http://${HOST}:${PORT}/health`);
  })
  .catch((error) => {
    app.log.error(error);
    process.exit(1);
  });
