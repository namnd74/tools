/**
 * Very small FIFO queue. We intentionally serialize browser interactions in V1
 * because one Copilot tab/conversation is not safe for concurrent prompts.
 */
export class SerialQueue {
  #tail = Promise.resolve();
  #pending = 0;

  get pending() {
    return this.#pending;
  }

  run(task) {
    this.#pending += 1;

    const execute = async () => {
      try {
        return await task();
      } finally {
        this.#pending -= 1;
      }
    };

    const result = this.#tail.then(execute, execute);
    this.#tail = result.catch(() => undefined);
    return result;
  }
}

export const browserQueue = new SerialQueue();
