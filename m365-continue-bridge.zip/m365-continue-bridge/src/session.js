import fs from "node:fs/promises";
import path from "node:path";
import { chromium } from "playwright";

const COPILOT_URL = process.env.M365_COPILOT_URL || "https://m365.cloud.microsoft/chat";
const PROFILE_DIR = path.resolve(process.env.M365_PROFILE_DIR || "./data/browser-profile");
const HEADLESS = String(process.env.M365_HEADLESS || "false").toLowerCase() === "true";
const CHANNEL = process.env.M365_BROWSER_CHANNEL || "msedge";

let context = null;
let page = null;

function isLoginUrl(url) {
  return /login\.microsoftonline\.com|login\.live\.com|login\.windows\.net|mysignins\.microsoft\.com/i.test(url);
}

async function launchPersistent() {
  await fs.mkdir(PROFILE_DIR, { recursive: true });

  const options = {
    headless: HEADLESS,
    viewport: { width: 1440, height: 1000 }
  };

  // Playwright can launch installed Edge via channel. If unavailable, fall back
  // to Playwright Chromium so the bridge still starts on macOS/Linux.
  try {
    context = await chromium.launchPersistentContext(PROFILE_DIR, {
      ...options,
      channel: CHANNEL
    });
  } catch (error) {
    console.warn(`[session] Could not launch browser channel '${CHANNEL}', falling back to chromium.`);
    console.warn(`[session] ${error.message}`);
    context = await chromium.launchPersistentContext(PROFILE_DIR, options);
  }

  const pages = context.pages();
  page = pages[0] || (await context.newPage());

  context.on("close", () => {
    context = null;
    page = null;
  });

  return page;
}

export async function getPage() {
  if (!context || !page || page.isClosed()) {
    await launchPersistent();
  }
  return page;
}

export async function openCopilot() {
  const p = await getPage();

  if (!p.url().startsWith("http") || isLoginUrl(p.url())) {
    await p.goto(COPILOT_URL, { waitUntil: "domcontentloaded", timeout: 120_000 });
  } else if (!/m365\.cloud\.microsoft|copilot\.microsoft/i.test(p.url())) {
    await p.goto(COPILOT_URL, { waitUntil: "domcontentloaded", timeout: 120_000 });
  }

  return p;
}

export async function getAuthState() {
  const p = await openCopilot();
  await p.waitForTimeout(1000);

  if (isLoginUrl(p.url())) {
    return "auth_required";
  }

  // We do not inspect/copy tokens. We judge auth from the actual web UI.
  const loginLike = await p.locator('input[type="email"], input[name="loginfmt"], input[type="password"]').count();
  if (loginLike > 0) {
    return "auth_required";
  }

  return "authenticated";
}

export async function ensureAuthenticated({ interactive = true } = {}) {
  const p = await openCopilot();
  let state = await getAuthState();
  if (state === "authenticated") return p;

  if (!interactive) {
    throw new Error("Microsoft 365 authentication required.");
  }

  console.log("[session] Microsoft sign-in is required.");
  console.log("[session] Complete login/MFA in the opened browser window. The bridge will continue automatically.");

  // The user completes Microsoft login in the persistent browser profile.
  const deadline = Date.now() + 5 * 60_000;
  while (Date.now() < deadline) {
    await p.waitForTimeout(1500);
    state = await getAuthState();
    if (state === "authenticated") {
      console.log("[session] Microsoft 365 session is authenticated.");
      return p;
    }
  }

  throw new Error("Timed out waiting for Microsoft 365 interactive login.");
}

export async function resetSession() {
  if (context) {
    await context.close().catch(() => undefined);
  }
  context = null;
  page = null;
}

export function getProfileDir() {
  return PROFILE_DIR;
}
