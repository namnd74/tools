import { ensureAuthenticated } from "./session.js";

const RESPONSE_TIMEOUT = Number(process.env.M365_RESPONSE_TIMEOUT_MS || 180000);

/**
 * IMPORTANT:
 * Microsoft can change Copilot Web's DOM at any time. Keep every UI selector in
 * this module so the rest of the bridge stays stable.
 */
const composerCandidates = [
  'textarea[placeholder*="message" i]',
  'textarea[placeholder*="copilot" i]',
  '[contenteditable="true"][role="textbox"]',
  'div[contenteditable="true"]'
];

const sendButtonCandidates = [
  'button[aria-label*="send" i]',
  'button[title*="send" i]',
  'button[data-testid*="send" i]'
];

const stopButtonCandidates = [
  'button[aria-label*="stop" i]',
  'button[title*="stop" i]'
];

const assistantMessageCandidates = [
  '[data-testid*="assistant" i]',
  '[data-message-author-role="assistant"]',
  '[data-author="assistant"]',
  'article'
];

async function firstVisible(page, selectors, timeout = 30_000) {
  const deadline = Date.now() + timeout;

  while (Date.now() < deadline) {
    for (const selector of selectors) {
      const locator = page.locator(selector).last();
      if ((await locator.count()) > 0 && (await locator.isVisible().catch(() => false))) {
        return locator;
      }
    }
    await page.waitForTimeout(300);
  }

  throw new Error(`Could not find a visible element. Tried: ${selectors.join(", ")}`);
}

async function getAssistantSnapshots(page) {
  const snapshots = [];
  for (const selector of assistantMessageCandidates) {
    const loc = page.locator(selector);
    const count = await loc.count();
    for (let i = 0; i < count; i += 1) {
      const item = loc.nth(i);
      if (!(await item.isVisible().catch(() => false))) continue;
      const text = (await item.innerText().catch(() => "")).trim();
      if (text) snapshots.push(text);
    }
  }
  return snapshots;
}

async function fillComposer(composer, text) {
  const tag = await composer.evaluate((el) => el.tagName.toLowerCase());
  if (tag === "textarea" || tag === "input") {
    await composer.fill(text);
    return;
  }

  await composer.click();
  await composer.press("ControlOrMeta+A").catch(() => undefined);
  await composer.press("Backspace").catch(() => undefined);
  await composer.evaluate((el, value) => {
    el.textContent = value;
    el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: value }));
  }, text);
}

async function submit(page, composer) {
  for (const selector of sendButtonCandidates) {
    const button = page.locator(selector).last();
    if ((await button.count()) > 0 && (await button.isVisible().catch(() => false))) {
      await button.click();
      return;
    }
  }

  // Most chat composers support Enter to send. Shift+Enter remains available for line breaks.
  await composer.press("Enter");
}

async function isGenerating(page) {
  for (const selector of stopButtonCandidates) {
    const button = page.locator(selector).last();
    if ((await button.count()) > 0 && (await button.isVisible().catch(() => false))) {
      return true;
    }
  }
  return false;
}

export async function sendCopilotPrompt(prompt) {
  const page = await ensureAuthenticated({ interactive: true });

  const before = await getAssistantSnapshots(page);
  const beforeLast = before.at(-1) || "";

  const composer = await firstVisible(page, composerCandidates, 60_000);
  await fillComposer(composer, prompt);
  await submit(page, composer);

  const deadline = Date.now() + RESPONSE_TIMEOUT;
  let lastText = "";
  let stableTicks = 0;
  let sawDifferentResponse = false;

  while (Date.now() < deadline) {
    // If Microsoft invalidates the browser session mid-request, surface a clear
    // auth failure rather than pretending the model returned an empty answer.
    if (/login\.microsoftonline\.com|login\.live\.com/i.test(page.url())) {
      throw new Error("Microsoft 365 session expired during the request. Re-authentication is required.");
    }

    const snapshots = await getAssistantSnapshots(page);
    const current = snapshots.at(-1) || "";

    if (current && current !== beforeLast) {
      sawDifferentResponse = true;
    }

    if (sawDifferentResponse && current) {
      if (current === lastText) stableTicks += 1;
      else stableTicks = 0;
      lastText = current;

      const generating = await isGenerating(page);
      if (!generating && stableTicks >= 3) {
        return current;
      }
    }

    await page.waitForTimeout(700);
  }

  if (lastText) return lastText;
  throw new Error("Timed out waiting for Microsoft 365 Copilot response. The Copilot Web selectors may need updating.");
}
